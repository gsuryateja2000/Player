# Pairing integration

The native player now exposes a persistent device identity to the `/tv` page:

- `window.SpaceQNative.getDeviceId()`
- `window.SpaceQNative.getPairingCode()`
- `window.SpaceQNative.getDeviceInfo()`

It also publishes:

`window.SpaceQDevice = { id, code, platform, version }`

and dispatches:

`window` event `spaceq-device-ready`

The CMS `/tv` page should read the code and ID and register/associate that
device in Firebase. The native APK cannot by itself create a Firebase document
in an unknown schema.

Example:

```js
const device = window.SpaceQDevice ||
  { id: window.SpaceQNative.getDeviceId(),
    code: window.SpaceQNative.getPairingCode() };

window.addEventListener('spaceq-device-ready', e => {
  const device = e.detail;
  // Register device using the SAME Firebase schema/API used by App 1.
});
```

Important: the 6-digit code is stable for the installation. It is not a
security credential; the CMS should still require authenticated operator
access to claim a device.
