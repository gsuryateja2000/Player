package com.spaceq.player

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class DeveloperSettingsActivity : Activity() {
    private lateinit var urlManager: PlayerUrlManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        urlManager = PlayerUrlManager(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.BLACK)
        }

        val title = TextView(this).apply {
            text = "SPACEQ Player — Developer Settings"
            textSize = 22f
            setTextColor(Color.WHITE)
        }

        val current = TextView(this).apply {
            text = "Current server"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }

        val input = EditText(this).apply {
            setText(urlManager.getUrl())
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "https://your-test-domain.vercel.app"
            setSingleLine(true)
        }

        val save = Button(this).apply {
            text = "Save & Reload Player"
            setOnClickListener {
                val url = input.text.toString().trim()
                if (url.isBlank()) {
                    Toast.makeText(this@DeveloperSettingsActivity, "Enter a URL", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                urlManager.setUrl(url)
                setResult(RESULT_OK)
                finish()
            }
        }

        val reset = Button(this).apply {
            text = "Reset to Default"
            setOnClickListener {
                urlManager.reset()
                input.setText(PlayerUrlManager.DEFAULT_URL)
                Toast.makeText(this@DeveloperSettingsActivity, "Default URL restored", Toast.LENGTH_SHORT).show()
            }
        }

        val close = Button(this).apply {
            text = "Close"
            setOnClickListener { finish() }
        }

        root.addView(title)
        root.addView(current, LinearLayout.LayoutParams(-1, -2))
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        root.addView(save, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        root.addView(reset, LinearLayout.LayoutParams(-1, -2))
        root.addView(close, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }
}
