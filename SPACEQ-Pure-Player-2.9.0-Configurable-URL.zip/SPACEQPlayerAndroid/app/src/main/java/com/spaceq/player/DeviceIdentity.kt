package com.spaceq.player

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.util.Locale

class DeviceIdentity(context: Context) {
    private val prefs = context.getSharedPreferences("spaceq_identity", Context.MODE_PRIVATE)

    val deviceId: String by lazy {
        prefs.getString("device_id", null) ?: createAndStoreDeviceId(context)
    }

    val pairingCode: String by lazy {
        prefs.getString("pairing_code", null) ?: createAndStorePairingCode()
    }

    private fun createAndStoreDeviceId(context: Context): String {
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty()

        val raw = if (androidId.isNotBlank()) {
            "spaceq:$androidId"
        } else {
            "spaceq:${System.currentTimeMillis()}:${android.os.Build.FINGERPRINT}"
        }

        val id = sha256(raw).take(16).uppercase(Locale.US)
        prefs.edit().putString("device_id", id).apply()
        return id
    }

    private fun createAndStorePairingCode(): String {
        // Stable 6-digit code for this installation.
        // It does not change on every launch or orientation change.
        val number = sha256("pair:$deviceId")
            .take(8)
            .toLong(16) % 1_000_000L
        val code = "%06d".format(Locale.US, number)
        prefs.edit().putString("pairing_code", code).apply()
        return code
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
