package com.spaceq.player

import android.content.Context

class PlayerUrlManager(context: Context) {
    private val prefs = context.getSharedPreferences("spaceq_player_settings", Context.MODE_PRIVATE)

    fun getUrl(): String =
        prefs.getString(KEY_URL, DEFAULT_URL)?.trim().orEmpty().ifBlank { DEFAULT_URL }

    fun setUrl(url: String) {
        prefs.edit().putString(KEY_URL, normalize(url)).apply()
    }

    fun reset() {
        prefs.edit().remove(KEY_URL).apply()
    }

    private fun normalize(url: String): String {
        val value = url.trim()
        return if (value.startsWith("http://") || value.startsWith("https://")) {
            value
        } else {
            "https://$value"
        }
    }

    companion object {
        // Change this once the final production domain is known.
        const val DEFAULT_URL = "https://spaceq-display-final.vercel.app"
        const val KEY_URL = "player_url"
    }
}
