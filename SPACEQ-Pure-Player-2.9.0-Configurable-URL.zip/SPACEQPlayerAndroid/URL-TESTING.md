# Changing the player URL during testing

The Pure Player no longer needs a rebuild when the testing Vercel domain changes.

1. Launch the player.
2. Long-press anywhere on the player screen for about 2 seconds.
3. Developer Settings opens.
4. Enter the current testing URL.
5. Tap **Save & Reload Player**.

The selected URL is stored locally and survives reboot.

Use **Reset to Default** to return to the built-in default URL.

For production, the developer settings activity can be removed/locked after
the final domain is confirmed.
