# Main SPACEQ `/tv` bridge patch

In `KioskDisplay.tsx`, whenever the Firestore device snapshot updates, call:

```ts
(window as any).SpaceQNative?.setOrientation?.(
  ((data.orientation || 'LANDSCAPE') as string).toUpperCase()
);
```

Because optional chaining is used, the same web app remains fully functional
in normal desktop browsers.

The Android Player then locks the physical Android output to the CMS-selected
orientation. The existing PlayerView CSS/grid logic continues to render the
same CMS layout.
