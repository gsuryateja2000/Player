# SPACEQ Pure Player 2.7.0

Dedicated Android TV/setup-box player. This is separate from the SPACEQ CMS.

## Runtime
- Fullscreen kiosk WebView
- Android TV/Leanback launcher
- Automatic boot start, including common QUICKBOOT broadcast
- Screen kept awake
- CMS-controlled orientation through `window.SpaceQNative.setOrientation()`
- Native private media cache, up to 4 GB
- Original media bytes are cached; Android does not recompress or resize them
- MP4/WebM/MOV byte ranges supported from local cache
- Reconnect detection triggers a player reload so Firestore can synchronize

## Critical architecture note
The native cache protects media assets. The `/tv` web app must also persist the
last known device/grid/playlist configuration locally if it must render after
a full Android reboot with NO INTERNET. WebView's normal HTTP cache is not a
guaranteed application data store.

The main `/tv` page should:
1. Persist the latest device configuration and active playlist/content manifest
   to localStorage/IndexedDB.
2. Restore that snapshot immediately when it loads offline.
3. Subscribe to Firestore while online and overwrite the snapshot when changes arrive.
4. Call:
   `window.SpaceQNative?.setOrientation?.(device.orientation)`
   whenever the CMS orientation changes.
5. Add a stable asset revision/version to media URLs when content is replaced,
   so the native cache stores the new asset rather than reusing the old URL.

## Quality
The player does not request `q_auto` or perform client-side compression.
The server-side media URL is the source of delivered quality.
