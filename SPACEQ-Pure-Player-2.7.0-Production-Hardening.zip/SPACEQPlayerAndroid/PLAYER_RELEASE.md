SPACEQ Pure Player 2.5.0

This release is the dedicated second application for Android TV/setup boxes.
The main SPACEQ dashboard is not part of this app.

Production endpoint:
https://YOUR-SPACEQ-DOMAIN/tv

The APK is designed to boot directly into the display player.
