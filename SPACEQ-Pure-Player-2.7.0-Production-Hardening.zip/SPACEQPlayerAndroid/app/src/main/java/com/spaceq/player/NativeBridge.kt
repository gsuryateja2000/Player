package com.spaceq.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.webkit.JavascriptInterface

class NativeBridge(private val activity: Activity) {
    @JavascriptInterface
    fun setOrientation(value: String) {
        activity.runOnUiThread {
            activity.requestedOrientation = when (value.uppercase()) {
                "PORTRAIT" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                "LANDSCAPE" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }
}