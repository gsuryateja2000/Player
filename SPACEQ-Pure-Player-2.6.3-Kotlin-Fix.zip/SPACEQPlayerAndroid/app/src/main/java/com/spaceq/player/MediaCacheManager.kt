package com.spaceq.player

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import kotlin.math.min

class MediaCacheManager(context: Context) {
    private val root = File(context.filesDir, "spaceq-media-cache").apply { mkdirs() }
    private val executor = Executors.newFixedThreadPool(3)
    private val maxBytes = 4L * 1024L * 1024L * 1024L // 4 GB cache for signage media

    fun intercept(url: String, range: String?): WebResourceResponse? {
        if (!isMediaUrl(url)) return null

        val file = fileFor(url)

        // If a complete copy is already present, never touch the network.
        if (file.exists() && file.length() > 0L) {
            return localResponse(file, url, range)
        }

        // First online request: download the original bytes to disk and return
        // them to WebView. No resizing, recompression, transcoding, or quality
        // transformation is performed here.
        return try {
            download(url, file)
            if (file.exists() && file.length() > 0L) localResponse(file, url, range) else null
        } catch (_: Exception) {
            // Let WebView make its normal request if our cache fetch failed.
            null
        }
    }

    private fun download(url: String, target: File) {
        if (target.exists() && target.length() > 0L) return
        val part = File(target.parentFile, "${target.name}.part")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 120000
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        try {
            c.connect()
            if (c.responseCode !in 200..299) return
            c.inputStream.use { input ->
                FileOutputStream(part).use { output -> input.copyTo(output) }
            }
            if (part.length() > 0L) {
                target.delete()
                part.renameTo(target)
                target.setLastModified(System.currentTimeMillis())
                trim()
            } else part.delete()
        } finally {
            c.disconnect()
        }
    }

    private fun localResponse(file: File, url: String, range: String?): WebResourceResponse {
        val total = file.length()
        val mime = mime(url)

        if (range.isNullOrBlank()) {
            return WebResourceResponse(
                mime, null, 200, "OK",
                mapOf(
                    "Accept-Ranges" to "bytes",
                    "Content-Length" to total.toString(),
                    "Cache-Control" to "public, max-age=31536000, immutable"
                ),
                FileInputStream(file)
            )
        }

        val match = Regex("bytes=(\\d+)-(\\d*)").find(range)
        val start = match?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
        if (start >= total) return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", emptyMap(), FileInputStream(file))

        val requestedEnd = match?.groupValues?.getOrNull(2)?.toLongOrNull()
        val end = min(requestedEnd ?: total - 1, total - 1)
        val length = end - start + 1
        val stream = FileInputStream(file).apply { skip(start) }

        return WebResourceResponse(
            mime, null, 206, "Partial Content",
            mapOf(
                "Accept-Ranges" to "bytes",
                "Content-Range" to "bytes $start-$end/$total",
                "Content-Length" to length.toString()
            ),
            BoundedInputStream(stream, length)
        )
    }

    private fun isMediaUrl(url: String): Boolean {
        val u = url.substringBefore("?").lowercase()
        return u.contains("res.cloudinary.com") ||
            u.endsWith(".jpg") || u.endsWith(".jpeg") || u.endsWith(".png") ||
            u.endsWith(".webp") || u.endsWith(".gif") || u.endsWith(".svg") ||
            u.endsWith(".mp4") || u.endsWith(".webm") || u.endsWith(".mov") ||
            u.endsWith(".m4v")
    }

    private fun fileFor(url: String) =
        File(root, sha256(url))

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun mime(url: String): String {
        val u = url.substringBefore("?").lowercase()
        return when {
            u.endsWith(".jpg") || u.endsWith(".jpeg") -> "image/jpeg"
            u.endsWith(".png") -> "image/png"
            u.endsWith(".webp") -> "image/webp"
            u.endsWith(".gif") -> "image/gif"
            u.endsWith(".svg") -> "image/svg+xml"
            u.endsWith(".mp4") -> "video/mp4"
            u.endsWith(".webm") -> "video/webm"
            u.endsWith(".mov") || u.endsWith(".m4v") -> "video/mp4"
            else -> "application/octet-stream"
        }
    }

    private fun trim() {
        var files = root.listFiles()?.filter { it.isFile } ?: return
        var size = files.sumOf { it.length() }
        if (size <= maxBytes) return
        files.sortedBy { it.lastModified() }.forEach {
            if (size <= maxBytes) return
            size -= it.length()
            it.delete()
        }
    }

    class BoundedInputStream(
        private val input: FileInputStream,
        private var remaining: Long
    ) : java.io.InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val r = input.read()
            if (r >= 0) remaining--
            return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = input.read(b, off, min(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }
        override fun close() = input.close()
    }
}