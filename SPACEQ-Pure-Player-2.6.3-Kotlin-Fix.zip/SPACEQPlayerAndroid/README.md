# SPACEQ Player — Pure Display APK 2.6.0

This is the second SPACEQ application. It is installed only on Android TV
boxes / Android setup boxes connected to customer TVs.

## Core behavior

1. Opens the dedicated SPACEQ `/tv` player.
2. The player receives the display configuration from the CMS/Firestore.
3. The Android layer downloads media to a private local cache on first play.
4. If internet is lost, cached images/videos continue playing.
5. When internet returns, the player reloads/revalidates and receives the
   latest CMS configuration/content.
6. Orientation follows the CMS `device.orientation` value:
   LANDSCAPE -> Android landscape
   PORTRAIT -> Android portrait
7. The Android layer never recompresses, resizes, or transcodes cached media.
8. Starts automatically after boot and keeps the screen awake.

## Important

The web `/tv` page remains responsible for pairing, playlists, grids,
scheduling and live configuration. The Android app is the execution layer.

For orientation to control the Android output, the deployed `/tv` page should
call `window.SpaceQNative?.setOrientation(device.orientation)` when its
device orientation changes. The Android app safely ignores this call on
ordinary browsers where the bridge does not exist.

Set the real `/tv` URL in `app/build.gradle.kts` before building.
