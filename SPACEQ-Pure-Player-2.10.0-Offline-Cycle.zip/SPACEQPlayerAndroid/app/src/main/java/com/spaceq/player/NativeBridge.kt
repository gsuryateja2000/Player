package com.spaceq.player

import android.app.Activity
import android.content.pm.ActivityInfo
import android.webkit.JavascriptInterface

class NativeBridge(
    private val activity: Activity,
    private val identity: DeviceIdentity,
    private val mediaCache: MediaCacheManager
) {
    @JavascriptInterface
    fun getDeviceId(): String = identity.deviceId

    @JavascriptInterface
    fun getPairingCode(): String = identity.pairingCode

    @JavascriptInterface
    fun getDeviceInfo(): String =
        """{"deviceId":"${identity.deviceId}","pairingCode":"${identity.pairingCode}","platform":"android","playerVersion":"2.8.0"}"""

    @JavascriptInterface
    fun cacheMedia(url: String) {
        mediaCache.prefetch(url)
    }

    @JavascriptInterface
    fun getCacheStats(): String = mediaCache.cacheStats()

    @JavascriptInterface
    fun setOrientation(value: String) {
        activity.runOnUiThread {
            activity.requestedOrientation = when (value.uppercase()) {
                "PORTRAIT" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                "LANDSCAPE" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }
}
