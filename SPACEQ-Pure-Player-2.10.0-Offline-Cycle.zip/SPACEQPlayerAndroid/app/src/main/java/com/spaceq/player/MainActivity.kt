package com.spaceq.player

import android.content.Intent

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var mediaCache: MediaCacheManager
    private lateinit var identity: DeviceIdentity
    private lateinit var playerUrlManager: PlayerUrlManager
    private val handler = Handler(Looper.getMainLooper())
    private var lastOnline = true

    private val connectivityCheck = object : Runnable {
        override fun run() {
            val online = isOnline()
            if (online && !lastOnline) {
                web.evaluateJavascript(
                    "(function(){try{window.dispatchEvent(new Event('spaceq-network-restored'));}catch(e){}})();",
                    null
                )
            }
            lastOnline = online
            handler.postDelayed(this, 5000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        mediaCache = MediaCacheManager(this)
        identity = DeviceIdentity(this)
        playerUrlManager = PlayerUrlManager(this)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = true
            offscreenPreRaster = true
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(web.settings, WebSettingsCompat.FORCE_DARK_OFF)
        }

        web.setBackgroundColor(0xFF000000.toInt())
        web.addJavascriptInterface(NativeBridge(this, identity, mediaCache), "SpaceQNative")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                val id = identity.deviceId.replace("\\", "\\\\").replace("'", "\\'")
                val code = identity.pairingCode
                view.evaluateJavascript(
                    """(function(){
                        window.SpaceQDevice={id:'$id',code:'$code',platform:'android',version:'2.8.0'};
                        window.dispatchEvent(new CustomEvent('spaceq-device-ready',{detail:window.SpaceQDevice}));
                    })();""",
                    null
                )
            }

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                return mediaCache.intercept(
                    url,
                    request.requestHeaders["Range"]
                ) ?: super.shouldInterceptRequest(view, request)
            }
        }

        web.setOnLongClickListener {
            startActivityForResult(
                Intent(this, DeveloperSettingsActivity::class.java),
                9001
            )
            true
        }

        web.loadUrl(playerUrlManager.getUrl())
        lastOnline = isOnline()
        handler.post(connectivityCheck)
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onResume() { super.onResume(); hideSystemUi(); if (::web.isInitialized) web.onResume() }
    override fun onPause() { if (::web.isInitialized) web.onPause(); super.onPause() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9001 && resultCode == RESULT_OK) {
            web.loadUrl(playerUrlManager.getUrl())
        }
    }


    override fun onDestroy() { handler.removeCallbacks(connectivityCheck); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}