# SPACEQ Pure Player 2.10

- Removes full WebView reload when network returns.
- Adds asynchronous native media prefetch.
- Adds adaptive cache sizing with storage safety reserve.
- Adds cache statistics bridge.
- Keeps original media bytes; no recompression/transcoding.
- Developer URL selection and pairing remain.
- Main `/tv` should call `window.SpaceQNative.cacheMedia(url)` for every
  assigned asset and should persist the last device/playlist/content snapshot
  locally for true offline reboot playback.
